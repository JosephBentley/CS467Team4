//
//  PhotoViewController.h
//  BillApp
//
//  Created by X Code User on 9/29/14.
//  Copyright (c) 2014 Team4. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoViewController : UIViewController
- (IBAction)takeReceipt:(id)sender;
- (IBAction)takeBarcode:(id)sender;
- (IBAction)existingReceipt:(id)sender;
- (IBAction)ExistingBarcode:(id)sender;


@end
