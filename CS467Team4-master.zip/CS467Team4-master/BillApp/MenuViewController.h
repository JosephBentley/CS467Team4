//
//  MenuViewController.h
//  BillApp
//
//  Created by X Code User on 10/6/14.
//  Copyright (c) 2014 Team4. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuViewController : UIViewController

@end
